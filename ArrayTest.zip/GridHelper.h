#ifndef GRID_HELPER_H
#define GRID_HELPER_H
#include <iostream>
class Grid;
std::ostream& operator<<(std::ostream&,const Grid&);


#endif //GRID_HELPER_H
